# FRS camera-ready / rebuttal data bundle

Packaged for Lonestar upload from the local `threshold/` workspace.
Generated: 2026-07-13T00:47:41.028927+00:00

## What this is
The **most important paper numbers and tables** already computed for COLM rebuttal /
camera-ready claims. Small (~7 MB). Does **not** include:
- raw pass@16 JSONL (~18 GB)
- PRM Math-Shepherd step scores (not present locally — still need LS6 / separate sync)
- full 13,500 FRS judge checkpoint JSONs (available separately as `frs_judged_all54.zip`)

## Map to camera-ready commitments

### 1. Family-controlled LOBO (ρ=0.495 primary; 0.712 uncontrolled)
- `analysis_outputs/rebuttal_easy_problem_family_checks/family_controlled_lobo_*`

### 2. PRM baseline
- **NOT IN THIS ZIP** — no PRM scoring artifacts in the local repo.

### 3. Held-out Haiku judge (r=0.367, agreement r=0.825)
- `analysis_outputs/selection_gain_heldout_haiku/`

### 4. Single-trace / unfiltered / top-1 ablations + amp + regression
- `results/rebuttal/` (tables.md, full_results.json, figures)
- `results_for_rebuttal.md` / `.json`
- `results_selectiongain_decisive.md` / `.json`
- `analysis_outputs/rebuttal_zero_cost/`
- `analysis_outputs/trace0_k1_judging/per_pair_scores.csv`
- `analysis_outputs/unfiltered_reasoning/per_pair_scores.csv`

### 5. Rubric dimension ablation (faith ρ=0.994, fact ρ=0.861; LODO amp)
- `analysis_outputs/rebuttal_dim_ablation/`
- `results_for_rebuttal.md` sections 4–6
- `diagnostics/dimension_correlations.csv`

### 6. Style controls (partial r=0.308)
- `analysis_outputs/exp_a_style_partial_corr/`

### 7. Easy-problem / top-10% concentration (63.8%, 16.4%, 22.3%)
- `analysis_outputs/rebuttal_easy_problem_family_checks/top10_*`
- `diagnostics/top10_concentration.csv`

### 8. Cost accounting
- `analysis_outputs/exp_f_cost_accounting/`

### 9–11. Method framing / code / gameability
- Prose only; no dedicated data packages. Style sensitivity for Phi-4-Reas. is in exp_a.

### Core FRS + selection-gain tables (paper backbone)
- `global_pass1_frs_analysis/*.csv`
- `analysis/selection_gain_*.csv`
- `analysis/frs_predictor_*.csv`

### Extra: filtered p1 mini-judge on 9 models (not PRM)
- `results/7b/filtered_p1_all_models_summary.*`
- `results/7b/judged_*_filtered_p1_only.{csv,json}`

## Unpack on Lonestar
```bash
mkdir -p ~/reasoning-models-eval/analysis_outputs/camera_ready_rebuttal_data
cd ~/reasoning-models-eval/analysis_outputs/camera_ready_rebuttal_data
unzip FRS_camera_ready_rebuttal_data.zip
```
